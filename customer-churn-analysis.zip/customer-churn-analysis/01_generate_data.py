"""
01_generate_data.py
-------------------
Generates a synthetic, Telco-style customer churn dataset (~7,000 customers)
and saves it as data/raw_telco_churn.csv.

The raw file is intentionally messy (blank TotalCharges, duplicate rows,
inconsistent labels, missing values) so the cleaning step in
02_clean_and_eda.py has real work to do.

Want to use real data instead? Download the public "Telco Customer Churn"
dataset (IBM sample data, on Kaggle), save it as data/raw_telco_churn.csv,
and skip this script. Column names are identical.
"""
import string
from pathlib import Path

import numpy as np
import pandas as pd

SEED = 42
N = 7043
TARGET_CHURN = 0.265  # overall churn rate to calibrate to
ROOT = Path(__file__).resolve().parent

rng = np.random.default_rng(SEED)


def pick(options, p, size=N):
    return rng.choice(options, size=size, p=p)


# ---- demographics ---------------------------------------------------------
gender = pick(["Male", "Female"], [0.5, 0.5])
senior = pick([0, 1], [0.84, 0.16])
partner = pick(["Yes", "No"], [0.48, 0.52])
dependents = np.where(
    partner == "Yes", pick(["Yes", "No"], [0.40, 0.60]), pick(["Yes", "No"], [0.10, 0.90])
)

# ---- account --------------------------------------------------------------
contract = pick(["Month-to-month", "One year", "Two year"], [0.55, 0.21, 0.24])
tenure = np.where(
    contract == "Month-to-month",
    rng.gamma(1.6, 11, N),
    np.where(contract == "One year", rng.normal(40, 18, N), rng.normal(56, 15, N)),
)
tenure = np.clip(np.round(tenure), 1, 72).astype(int)
tenure[rng.choice(N, 11, replace=False)] = 0  # brand-new customers, no bill yet

paperless = pick(["Yes", "No"], [0.59, 0.41])
payment = pick(
    ["Electronic check", "Mailed check", "Bank transfer (automatic)", "Credit card (automatic)"],
    [0.34, 0.23, 0.22, 0.21],
)

# ---- services -------------------------------------------------------------
phone = pick(["Yes", "No"], [0.90, 0.10])
multi = np.where(phone == "No", "No phone service", pick(["Yes", "No"], [0.47, 0.53]))
internet = pick(["DSL", "Fiber optic", "No"], [0.34, 0.44, 0.22])


def addon(p_yes):
    return np.where(internet == "No", "No internet service", pick(["Yes", "No"], [p_yes, 1 - p_yes]))


security, backup, protection = addon(0.29), addon(0.34), addon(0.34)
support, tv, movies = addon(0.29), addon(0.38), addon(0.39)

# ---- charges --------------------------------------------------------------
monthly = np.where(phone == "Yes", 20.0, 0.0)
monthly += np.select([internet == "DSL", internet == "Fiber optic"], [25.0, 55.0], 0.0)
for col, price in [(security, 5), (backup, 5), (protection, 5), (support, 5), (tv, 10), (movies, 10)]:
    monthly += np.where(col == "Yes", price, 0)
monthly += np.where(multi == "Yes", 5, 0)
monthly += rng.normal(0, 3, N)
monthly = np.round(np.clip(monthly, 18.25, 120), 2)

total = np.round(monthly * tenure * rng.normal(1.0, 0.03, N), 2)

# ---- churn (logistic model, intercept calibrated to TARGET_CHURN) ----------
z = (
    np.select([contract == "Month-to-month", contract == "One year"], [1.3, -0.5], -1.8)
    + np.select([internet == "Fiber optic", internet == "DSL"], [0.7, -0.1], -0.9)
    - 0.035 * tenure
    + np.where(support == "Yes", -0.6, 0)
    + np.where(security == "Yes", -0.5, 0)
    + np.where(payment == "Electronic check", 0.7, 0)
    + 0.35 * senior
    + 0.25 * (paperless == "Yes")
    + 0.012 * (monthly - 65)
    - 0.3 * (dependents == "Yes")
    - 0.15 * (partner == "Yes")
)
lo, hi = -6.0, 6.0
for _ in range(60):
    mid = (lo + hi) / 2
    if (1 / (1 + np.exp(-(z + mid)))).mean() > TARGET_CHURN:
        hi = mid
    else:
        lo = mid
prob = 1 / (1 + np.exp(-(z + mid)))
churn = np.where(rng.random(N) < prob, "Yes", "No")
churn[tenure == 0] = "No"

# ---- assemble --------------------------------------------------------------
letters = list(string.ascii_uppercase)
ids = [f"{(i * 7919) % 10000:04d}-{''.join(rng.choice(letters, 5))}" for i in range(N)]

df = pd.DataFrame(
    {
        "customerID": ids,
        "gender": gender,
        "SeniorCitizen": senior,
        "Partner": partner,
        "Dependents": dependents,
        "tenure": tenure,
        "PhoneService": phone,
        "MultipleLines": multi,
        "InternetService": internet,
        "OnlineSecurity": security,
        "OnlineBackup": backup,
        "DeviceProtection": protection,
        "TechSupport": support,
        "StreamingTV": tv,
        "StreamingMovies": movies,
        "Contract": contract,
        "PaperlessBilling": paperless,
        "PaymentMethod": payment,
        "MonthlyCharges": monthly,
        # stored as text with a blank for new customers, like the public dataset
        "TotalCharges": [" " if t == 0 else f"{v:.2f}" for t, v in zip(tenure, total)],
        "Churn": churn,
    }
)

# ---- make it messy ---------------------------------------------------------
df.loc[rng.choice(N, 20, replace=False), "MonthlyCharges"] = np.nan

bad = rng.choice(N, 60, replace=False)
df.loc[bad[:30], "Contract"] = df.loc[bad[:30], "Contract"].str.upper()
df.loc[bad[30:], "PaymentMethod"] = df.loc[bad[30:], "PaymentMethod"].str.lower() + " "

short_g = rng.choice(N, 25, replace=False)
df.loc[short_g, "gender"] = df.loc[short_g, "gender"].str[0]  # "M" / "F"

dups = df.sample(40, random_state=SEED)
df = pd.concat([df, dups]).sample(frac=1, random_state=SEED).reset_index(drop=True)

out = ROOT / "data" / "raw_telco_churn.csv"
out.parent.mkdir(exist_ok=True)
df.to_csv(out, index=False)
print(f"Saved {len(df):,} rows x {df.shape[1]} columns -> {out}")
