# Power BI Guide: Customer Churn Dashboard

Static preview of the target layout: `../charts/dashboard_preview.png`

## 1. Load the data

1. Power BI Desktop -> **Get data -> Text/CSV** -> choose `data/clean_telco_churn.csv`.
2. Click **Transform Data** and confirm types:
   - `tenure`, `ChurnFlag`, `SeniorCitizen`, `AddOnServices`, `TenureGroupOrder`, `ChargeBandOrder` -> Whole number
   - `MonthlyCharges`, `TotalCharges` -> Fixed decimal number
   - everything else -> Text
3. **Close & Apply**. The table is named `clean_telco_churn` (the DAX below uses that name).

## 2. Fix the sort order of text columns

Select the column, then **Column tools -> Sort by column**:

| Column | Sort by |
|---|---|
| `TenureGroup` | `TenureGroupOrder` |
| `ChargeBand` | `ChargeBandOrder` |

Without this, "0-12 months" and "13-24 months" sort alphabetically and the retention curve looks wrong.

## 3. DAX measures

Create a blank table called `_Measures` (Home -> Enter data) and add these measures to it.

```dax
Total Customers = DISTINCTCOUNT ( clean_telco_churn[customerID] )

Churned Customers =
CALCULATE ( [Total Customers], clean_telco_churn[ChurnFlag] = 1 )

Retained Customers = [Total Customers] - [Churned Customers]

Churn Rate % = DIVIDE ( [Churned Customers], [Total Customers] )

Retention Rate % = 1 - [Churn Rate %]

Monthly Revenue = SUM ( clean_telco_churn[MonthlyCharges] )

Revenue Lost to Churn =
CALCULATE ( SUM ( clean_telco_churn[MonthlyCharges] ), clean_telco_churn[ChurnFlag] = 1 )

Revenue Churn % = DIVIDE ( [Revenue Lost to Churn], [Monthly Revenue] )

Annualised Revenue Lost = [Revenue Lost to Churn] * 12

Avg Tenure (Churned) =
CALCULATE ( AVERAGE ( clean_telco_churn[tenure] ), clean_telco_churn[ChurnFlag] = 1 )

Avg Tenure (Retained) =
CALCULATE ( AVERAGE ( clean_telco_churn[tenure] ), clean_telco_churn[ChurnFlag] = 0 )

Avg Monthly Charge (Churned) =
CALCULATE ( AVERAGE ( clean_telco_churn[MonthlyCharges] ), clean_telco_churn[ChurnFlag] = 1 )

Early Churn % =
DIVIDE (
    CALCULATE ( [Churned Customers], clean_telco_churn[tenure] <= 12 ),
    [Churned Customers]
)

Churn Rate vs Average =
[Churn Rate %] - CALCULATE ( [Churn Rate %], ALL ( clean_telco_churn ) )

High-Risk Customers =
CALCULATE (
    [Total Customers],
    clean_telco_churn[Contract] = "Month-to-month",
    clean_telco_churn[InternetService] = "Fiber optic",
    clean_telco_churn[PaymentMethod] = "Electronic check"
)

High-Risk Churn Rate =
CALCULATE (
    [Churn Rate %],
    clean_telco_churn[Contract] = "Month-to-month",
    clean_telco_churn[InternetService] = "Fiber optic",
    clean_telco_churn[PaymentMethod] = "Electronic check"
)
```

Format: the `%` measures as Percentage (1 decimal), revenue measures as Currency, tenure as Decimal (0).

## 4. Page layout (matches the preview image)

**Page 1: Churn Overview**

| Area | Visual | Fields |
|---|---|---|
| Top row (4 cards) | Card | `Total Customers`, `Churn Rate %`, `Revenue Lost to Churn`, `Avg Tenure (Churned)` |
| Row 1, left | Clustered column | Axis `Contract`, Values `Churn Rate %` |
| Row 1, middle | Clustered column | Axis `TenureGroup`, Values `Churn Rate %` |
| Row 1, right | Clustered column | Axis `InternetService`, Values `Churn Rate %` |
| Row 2, left | Clustered column | Axis `PaymentMethod`, Values `Churn Rate %` |
| Row 2, middle | Clustered column | Axis `TechSupport`, Values `Churn Rate %` (filter `InternetService` is not "No") |
| Row 2, right | Clustered column | Axis `ChargeBand`, Values `Churn Rate %` |
| Left rail | Slicers | `Contract`, `InternetService`, `PaymentMethod`, `SeniorCitizenLabel`, `TenureGroup` |

For every bar chart: turn on **Data labels**, add an **Average line** (Analytics pane) at the overall churn rate, and set the bar color to `#eb6834`.

**Page 2: Retention Deep Dive**

- Line chart: Axis `tenure` (bin size 6), Values `Churn Rate %`
- Matrix: Rows `Contract`, Columns `InternetService`, Values `Churn Rate %`, conditional-format the cells (white -> `#eb6834`)
- Cards: `High-Risk Customers`, `High-Risk Churn Rate`, `Early Churn %`
- Scatter: X `tenure`, Y `MonthlyCharges`, Legend `Churn` (Retained `#2a78d6`, Churned `#eb6834`)

**Page 3 (optional): Customer list**

- Table with `customerID`, `Contract`, `tenure`, `MonthlyCharges`, `Churn`, filtered to the high-risk segment, so a retention team can action it.

## 5. Theme

- Retained = `#2a78d6` (blue), Churned = `#eb6834` (orange). Both pass colorblind-separation checks.
- Background `#fcfcfb`, text `#0b0b0b`, secondary text `#52514e`, gridlines `#e1e0d9`.
- Set these under **View -> Themes -> Customize current theme**, or save a JSON theme.

## 6. Publish / share

- **File -> Export -> PDF** for a quick share, or **Publish** to the Power BI Service (needs a work/school account).
- Take a screenshot of each page for the GitHub README (`charts/` already has a static preview).
