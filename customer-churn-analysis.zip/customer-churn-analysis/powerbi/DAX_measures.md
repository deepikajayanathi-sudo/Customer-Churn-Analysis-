# DAX Measures (table: `customer_churn_clean`)

```DAX
Total Customers   = COUNTROWS(customer_churn_clean)
Churned Customers = CALCULATE([Total Customers], customer_churn_clean[Churn] = "Yes")
Retained Customers = [Total Customers] - [Churned Customers]
Churn Rate %      = DIVIDE([Churned Customers], [Total Customers], 0)
Retention Rate %  = 1 - [Churn Rate %]
Avg Monthly Charges = AVERAGE(customer_churn_clean[MonthlyCharges])
Avg Tenure (Months) = AVERAGE(customer_churn_clean[tenure])
Monthly Revenue at Risk = CALCULATE(SUM(customer_churn_clean[MonthlyCharges]), customer_churn_clean[Churn] = "Yes")
Lifetime Value Lost = CALCULATE(SUM(customer_churn_clean[TotalCharges]), customer_churn_clean[Churn] = "Yes")
Churn Rate vs Overall =
    [Churn Rate %] - CALCULATE([Churn Rate %], ALL(customer_churn_clean))
High Risk Active Customers =
    CALCULATE([Total Customers], customer_churn_clean[Churn] = "No", customer_churn_clean[ChurnProbability] >= 0.6)
```

# Power BI Build Steps
1. **Get Data → Text/CSV** → `data/processed/customer_churn_clean.csv` (also optionally `churn_by_segment.csv`, `feature_importance.csv`). Click *Transform*: confirm `ChurnProbability`, `MonthlyCharges`, `TotalCharges` are Decimal; `tenure` Whole.
2. **Sort order**: select `TenureGroup` → Column tools → Sort by column (add a helper index) so buckets order 0-12 → 49-72; same for `ChargeBand`.
3. Create the measures above (Modeling → New measure).
4. Build 3 pages:

| Page | Visuals |
|---|---|
| **1. Executive Overview** | KPI cards: Total Customers, Churn Rate %, Retention Rate %, Monthly Revenue at Risk, Avg Tenure · Donut: Churn vs Retained · Column: Churn Rate % by Contract · Line/Column: Churn Rate % by TenureGroup |
| **2. Churn Drivers** | Clustered bars: Churn Rate % by InternetService, PaymentMethod, TechSupport, OnlineSecurity, SeniorCitizen · Matrix heatmap (Contract × TenureGroup, value = Churn Rate %, conditional-format background) · Decomposition tree (Analyze = Churn Rate %) |
| **3. At-Risk Customers** | Table: customerID, Contract, tenure, MonthlyCharges, ChurnProbability (filter Churn = No, sort desc, data bars) · Card: High Risk Active Customers · Scatter: tenure vs MonthlyCharges coloured by Churn |

5. **Slicers (sync across pages)**: Contract, InternetService, gender, SeniorCitizen, TenureGroup.
6. **Theme**: blue `#2E86AB` = retained, red `#E4572E` = churned. Add tooltips with Churn Rate vs Overall.
7. Save as `powerbi/Customer_Churn_Dashboard.pbix`; screenshot each page to `images/`.
