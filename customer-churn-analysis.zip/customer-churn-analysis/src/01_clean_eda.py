"""Customer Churn Analysis: data cleaning + EDA + Power BI export."""
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns
from scipy.stats import chi2_contingency
sns.set_theme(style="whitegrid", palette=["#2E86AB","#E4572E"])
RAW, OUT, IMG = "data/raw/customer_churn_raw.csv", "data/processed/", "images/"

# ---------- 1. LOAD & AUDIT ----------
df = pd.read_csv(RAW)
log = [f"Raw shape: {df.shape}"]
log.append(f"Duplicate rows: {df.duplicated().sum()}")
log.append("Missing values:\n" + df.isna().sum()[lambda s: s>0].to_string())

# ---------- 2. CLEANING ----------
df = df.drop_duplicates().copy()
df["gender"] = df["gender"].str.strip().str.title()
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"].astype(str).str.strip(), errors="coerce")
log.append(f"TotalCharges blank/non-numeric: {df['TotalCharges'].isna().sum()} (tenure=0 new customers -> set to 0)")
df.loc[(df.tenure==0) & df.TotalCharges.isna(), "TotalCharges"] = 0
# impute MonthlyCharges with median of same InternetService group; PaymentMethod with mode
df["MonthlyCharges"] = df["MonthlyCharges"].fillna(df.groupby("InternetService")["MonthlyCharges"].transform("median"))
df["PaymentMethod"] = df["PaymentMethod"].fillna(df["PaymentMethod"].mode()[0])
df["SeniorCitizen"] = df["SeniorCitizen"].map({0:"No",1:"Yes"})
df["ChurnFlag"] = (df["Churn"]=="Yes").astype(int)

# ---------- 3. FEATURE ENGINEERING ----------
df["TenureGroup"] = pd.cut(df.tenure, [-1,12,24,48,72], labels=["0-12 mo","13-24 mo","25-48 mo","49-72 mo"])
df["ChargeBand"] = pd.cut(df.MonthlyCharges, [0,35,65,90,200], labels=["Low (<35)","Medium (35-65)","High (65-90)","Premium (90+)"])
addons = ["OnlineSecurity","OnlineBackup","DeviceProtection","TechSupport","StreamingTV","StreamingMovies"]
df["AddOnCount"] = (df[addons]=="Yes").sum(axis=1)
df["AutoPay"] = df.PaymentMethod.str.contains("automatic").map({True:"Yes",False:"No"})
df["RiskSegment"] = np.where((df.Contract=="Month-to-month")&(df.tenure<=12),"High risk",
                     np.where(df.Contract=="Month-to-month","Medium risk","Low risk"))
log.append(f"Clean shape: {df.shape}; remaining nulls: {int(df.isna().sum().sum())}")

# ---------- 4. EDA ----------
rate = df.ChurnFlag.mean()
log.append(f"\nOverall churn rate: {rate:.1%} | churned: {df.ChurnFlag.sum()} of {len(df)}")
log.append(f"Revenue lost per month (churned MonthlyCharges): ${df.loc[df.ChurnFlag==1,'MonthlyCharges'].sum():,.0f}")
cats = ["Contract","InternetService","PaymentMethod","TenureGroup","SeniorCitizen","PaperlessBilling",
        "TechSupport","OnlineSecurity","Partner","Dependents","AutoPay","RiskSegment","ChargeBand"]
rows=[]
for c in cats:
    g = df.groupby(c, observed=True).ChurnFlag.agg(["mean","sum","count"])
    for k,r in g.iterrows(): rows.append((c,k,r["count"],r["sum"],r["mean"]))
    chi2,p,_,_ = chi2_contingency(pd.crosstab(df[c], df.ChurnFlag))
    log.append(f"Chi-square {c:<17} p={p:.2e} {'(significant)' if p<.05 else '(not significant)'}")
seg = pd.DataFrame(rows, columns=["Feature","Category","Customers","Churned","ChurnRate"]).sort_values("ChurnRate",ascending=False)
seg.to_csv(OUT+"churn_by_segment.csv", index=False)
log.append("\nTop 8 highest-churn segments:\n" + seg.head(8).round(3).to_string(index=False))

# ---------- 5. CHARTS ----------
def bar(col, title, fname, order=None):
    g = df.groupby(col, observed=True).ChurnFlag.mean().mul(100)
    if order: g = g.reindex(order)
    fig, ax = plt.subplots(figsize=(7,4))
    bars = ax.bar(g.index.astype(str), g.values, color="#2E86AB")
    ax.axhline(rate*100, color="#E4572E", ls="--", label=f"Overall {rate:.1%}")
    for b,v in zip(bars,g.values): ax.text(b.get_x()+b.get_width()/2, v+.5, f"{v:.1f}%", ha="center", fontsize=9)
    ax.set(title=title, ylabel="Churn rate (%)"); ax.legend(); plt.xticks(rotation=15)
    plt.tight_layout(); plt.savefig(IMG+fname, dpi=150); plt.close()
bar("Contract","Churn Rate by Contract Type","churn_by_contract.png")
bar("TenureGroup","Churn Rate by Tenure","churn_by_tenure.png")
bar("InternetService","Churn Rate by Internet Service","churn_by_internet.png")
bar("PaymentMethod","Churn Rate by Payment Method","churn_by_payment.png")
fig, ax = plt.subplots(1,2,figsize=(11,4))
df.ChurnFlag.value_counts().rename({0:"Retained",1:"Churned"}).plot.pie(ax=ax[0],autopct="%1.1f%%",colors=["#2E86AB","#E4572E"],ylabel="")
ax[0].set_title("Churn Split")
sns.kdeplot(data=df, x="MonthlyCharges", hue="Churn", fill=True, ax=ax[1], common_norm=False)
ax[1].set_title("Monthly Charges: Churned vs Retained")
plt.tight_layout(); plt.savefig(IMG+"churn_overview.png", dpi=150); plt.close()
num = df[["tenure","MonthlyCharges","TotalCharges","AddOnCount","ChurnFlag"]]
plt.figure(figsize=(6,5)); sns.heatmap(num.corr(),annot=True,fmt=".2f",cmap="RdBu_r",center=0)
plt.title("Correlation Matrix"); plt.tight_layout(); plt.savefig(IMG+"correlation.png", dpi=150); plt.close()

# ---------- 6. QUICK PREDICTIVE MODEL (drivers) ----------
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score, classification_report
X = pd.get_dummies(df.drop(columns=["customerID","Churn","ChurnFlag","TenureGroup","ChargeBand","RiskSegment"]), drop_first=True)
Xtr,Xte,ytr,yte = train_test_split(X, df.ChurnFlag, test_size=.25, stratify=df.ChurnFlag, random_state=42)
rf = RandomForestClassifier(300, max_depth=8, class_weight="balanced", random_state=42, n_jobs=-1).fit(Xtr,ytr)
proba = rf.predict_proba(Xte)[:,1]
log.append(f"\nRandomForest ROC-AUC: {roc_auc_score(yte,proba):.3f}\n" + classification_report(yte, rf.predict(Xte)))
imp = pd.Series(rf.feature_importances_, index=X.columns).sort_values(ascending=False)
imp.head(10).to_csv(OUT+"feature_importance.csv", header=["importance"])
imp.head(10)[::-1].plot.barh(figsize=(7,4.5), color="#2E86AB", title="Top 10 Churn Drivers (Random Forest)")
plt.tight_layout(); plt.savefig(IMG+"feature_importance.png", dpi=150); plt.close()
df["ChurnProbability"] = np.round(rf.predict_proba(X)[:,1],3)

# ---------- 7. EXPORT FOR POWER BI ----------
df.to_csv(OUT+"customer_churn_clean.csv", index=False)
open("data/processed/eda_log.txt","w").write("\n".join(log)); print("\n".join(log))
