"""Generate a realistic, deliberately messy telecom-style churn dataset (7,043 rows).
Replace data/raw/customer_churn_raw.csv with the real IBM/Kaggle Telco file if you prefer;
01_clean_eda.py works with either (same column names)."""
import numpy as np, pandas as pd
rng = np.random.default_rng(42)
n = 7043
ids = [f"{rng.integers(1000,9999)}-{''.join(rng.choice(list('ABCDEFGHIJKLMNOPQRSTUVWXYZ'),5))}" for _ in range(n)]
gender = rng.choice(["Male","Female"], n)
senior = rng.choice([0,1], n, p=[.84,.16])
partner = rng.choice(["Yes","No"], n)
dependents = rng.choice(["Yes","No"], n, p=[.3,.7])
contract = rng.choice(["Month-to-month","One year","Two year"], n, p=[.55,.21,.24])
tenure = np.where(contract=="Month-to-month", rng.integers(1,40,n),
         np.where(contract=="One year", rng.integers(6,60,n), rng.integers(12,73,n)))
internet = rng.choice(["DSL","Fiber optic","No"], n, p=[.34,.44,.22])
def addon(p=.45):
    v = rng.choice(["Yes","No"], n, p=[p,1-p])
    return np.where(internet=="No","No internet service",v)
sec, backup, prot, tech, tv, movies = [addon(.4) for _ in range(6)]
tech = addon(.35)
phone = rng.choice(["Yes","No"], n, p=[.9,.1])
multi = np.where(phone=="No","No phone service",rng.choice(["Yes","No"],n))
paperless = rng.choice(["Yes","No"], n, p=[.6,.4])
payment = rng.choice(["Electronic check","Mailed check","Bank transfer (automatic)","Credit card (automatic)"], n, p=[.34,.23,.22,.21])
monthly = np.round(np.where(internet=="No",20,np.where(internet=="DSL",45,78)) + rng.normal(0,9,n)
          + 5*(sec=="Yes") + 5*(backup=="Yes") + 5*(tv=="Yes") + 5*(movies=="Yes"),2).clip(18.25,119)
total = np.round(monthly*tenure*rng.uniform(.95,1.05,n),2)
# churn logit
z = (-1.0 + 1.5*(contract=="Month-to-month") - 1.2*(contract=="Two year") + .8*(internet=="Fiber optic")
     + .7*(payment=="Electronic check") - .035*tenure + .008*(monthly-65) + .3*senior
     - .5*(sec=="Yes") - .5*(tech=="Yes") + .2*(paperless=="Yes") - .2*(partner=="Yes"))
p = 1/(1+np.exp(-(z-0.35)))
churn = np.where(rng.random(n)<p,"Yes","No")
df = pd.DataFrame(dict(customerID=ids,gender=gender,SeniorCitizen=senior,Partner=partner,Dependents=dependents,
  tenure=tenure,PhoneService=phone,MultipleLines=multi,InternetService=internet,OnlineSecurity=sec,
  OnlineBackup=backup,DeviceProtection=prot,TechSupport=tech,StreamingTV=tv,StreamingMovies=movies,
  Contract=contract,PaperlessBilling=paperless,PaymentMethod=payment,MonthlyCharges=monthly,
  TotalCharges=total.astype(object),Churn=churn))
# --- inject mess ---
blank = rng.choice(n, 11, replace=False); df.loc[blank,"TotalCharges"]=" "; df.loc[blank,"tenure"]=0
df.loc[rng.choice(n,60,replace=False),"gender"]=rng.choice(["male","FEMALE"," Male"],60)
df.loc[rng.choice(n,45,replace=False),"MonthlyCharges"]=np.nan
df.loc[rng.choice(n,30,replace=False),"PaymentMethod"]=np.nan
df = pd.concat([df, df.sample(25, random_state=1)], ignore_index=True)  # duplicates
df.to_csv("data/raw/customer_churn_raw.csv", index=False)
print(df.shape)
