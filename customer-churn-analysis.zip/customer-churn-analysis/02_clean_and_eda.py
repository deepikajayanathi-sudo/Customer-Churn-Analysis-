"""
02_clean_and_eda.py
-------------------
Customer churn analysis: data cleaning + exploratory data analysis (EDA).

Input : data/raw_telco_churn.csv
Output: data/clean_telco_churn.csv     (load this into Power BI)
        data/churn_by_segment.csv      (churn rate for every category value)
        data/analysis_log.txt          (cleaning steps + key findings)
        charts/*.png                   (static charts + dashboard preview)

Run:  python 02_clean_and_eda.py
Cells are marked with '# %%' so the file also runs cell-by-cell in VS Code / Jupyter.
"""

# %% 1. Setup -----------------------------------------------------------------
import textwrap
from pathlib import Path

import matplotlib

if "__file__" in globals():  # running as a script -> no GUI backend needed
    matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import FancyBboxPatch
from matplotlib.ticker import PercentFormatter

ROOT = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()
DATA, CHARTS = ROOT / "data", ROOT / "charts"
CHARTS.mkdir(exist_ok=True)

log = []


def note(msg=""):
    print(msg)
    log.append(msg)


# %% 2. Load + audit the raw data ---------------------------------------------
raw = pd.read_csv(DATA / "raw_telco_churn.csv")

note("=== 1. DATA AUDIT (raw file) ===")
note(f"Shape: {raw.shape[0]:,} rows x {raw.shape[1]} columns")
note(f"Exact duplicate rows      : {raw.duplicated().sum()}")
note(f"Missing MonthlyCharges    : {raw['MonthlyCharges'].isna().sum()}")
note(f"Blank TotalCharges (text) : {(raw['TotalCharges'].astype(str).str.strip() == '').sum()}")
note(f"gender labels             : {sorted(raw['gender'].astype(str).unique())}")
note(f"Contract labels           : {sorted(raw['Contract'].astype(str).unique())}")
note(f"PaymentMethod labels      : {raw['PaymentMethod'].nunique()} distinct (expected 4)")

# %% 3. Clean ------------------------------------------------------------------
note("\n=== 2. CLEANING ===")
df = raw.copy()

TEXT_COLS = [
    "customerID", "gender", "Partner", "Dependents", "PhoneService", "MultipleLines",
    "InternetService", "OnlineSecurity", "OnlineBackup", "DeviceProtection", "TechSupport",
    "StreamingTV", "StreamingMovies", "Contract", "PaperlessBilling", "PaymentMethod", "Churn",
]
for c in TEXT_COLS:
    df[c] = df[c].astype(str).str.strip()

# 3a. Standardise inconsistent labels
df["gender"] = df["gender"].str.upper().map(
    {"M": "Male", "F": "Female", "MALE": "Male", "FEMALE": "Female"}
)
df["Contract"] = df["Contract"].str.lower().map(
    {"month-to-month": "Month-to-month", "one year": "One year", "two year": "Two year"}
)
df["PaymentMethod"] = df["PaymentMethod"].str.lower().map(
    {
        "electronic check": "Electronic check",
        "mailed check": "Mailed check",
        "bank transfer (automatic)": "Bank transfer (automatic)",
        "credit card (automatic)": "Credit card (automatic)",
    }
)
assert df[["gender", "Contract", "PaymentMethod"]].isna().sum().sum() == 0
note("Standardised gender / Contract / PaymentMethod labels (case + whitespace + abbreviations)")

# 3b. Remove duplicate customer records
before = len(df)
df = df.drop_duplicates(subset="customerID", keep="first").reset_index(drop=True)
note(f"Removed {before - len(df)} duplicate customer records -> {len(df):,} unique customers")

# 3c. TotalCharges is text with blanks -> numeric. Blank = brand-new customer (tenure 0), so 0.
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
blank_total = df["TotalCharges"].isna().sum()
df.loc[df["tenure"] == 0, "TotalCharges"] = 0.0
df["TotalCharges"] = df["TotalCharges"].fillna(df["MonthlyCharges"] * df["tenure"])
note(f"Converted TotalCharges to numeric; set {blank_total} blank values (tenure = 0) to 0")

# 3d. Missing MonthlyCharges: TotalCharges / tenure when possible, else group median
miss = df["MonthlyCharges"].isna()
est = (df["TotalCharges"] / df["tenure"].replace(0, np.nan)).round(2)
df.loc[miss, "MonthlyCharges"] = est[miss]
grp_median = df.groupby(["InternetService", "PhoneService"])["MonthlyCharges"].transform("median")
df["MonthlyCharges"] = df["MonthlyCharges"].fillna(grp_median).round(2)
note(f"Imputed {miss.sum()} missing MonthlyCharges (TotalCharges/tenure, else median of service group)")

# 3e. Target + readable flags
df["ChurnFlag"] = (df["Churn"] == "Yes").astype(int)
df["SeniorCitizenLabel"] = np.where(df["SeniorCitizen"] == 1, "Yes", "No")

# 3f. Feature engineering (used in the Power BI dashboard)
df["TenureGroup"] = pd.cut(
    df["tenure"], bins=[-1, 12, 24, 48, 72],
    labels=["0-12 months", "13-24 months", "25-48 months", "49-72 months"],
).astype(str)
df["TenureGroupOrder"] = pd.cut(df["tenure"], bins=[-1, 12, 24, 48, 72], labels=False).astype(int) + 1

ADDONS = ["OnlineSecurity", "OnlineBackup", "DeviceProtection", "TechSupport", "StreamingTV", "StreamingMovies"]
df["AddOnServices"] = (df[ADDONS] == "Yes").sum(axis=1)

df["ChargeBand"] = pd.cut(
    df["MonthlyCharges"], bins=[0, 35, 70, 500], labels=["Low (<35)", "Medium (35-70)", "High (>70)"]
).astype(str)
df["ChargeBandOrder"] = pd.cut(df["MonthlyCharges"], bins=[0, 35, 70, 500], labels=False).astype(int) + 1
note("Engineered: ChurnFlag, SeniorCitizenLabel, TenureGroup(+Order), AddOnServices, ChargeBand(+Order)")

assert df.isna().sum().sum() == 0 and df["customerID"].is_unique
df.to_csv(DATA / "clean_telco_churn.csv", index=False)
note(f"Saved clean data: {df.shape[0]:,} rows x {df.shape[1]} columns -> data/clean_telco_churn.csv")

# %% 4. EDA: headline numbers -------------------------------------------------
note("\n=== 3. HEADLINE NUMBERS ===")
overall = df["ChurnFlag"].mean()
mrr = df["MonthlyCharges"].sum()
lost = df.loc[df["ChurnFlag"] == 1, "MonthlyCharges"].sum()
ten_ch = df.loc[df["ChurnFlag"] == 1, "tenure"].mean()
ten_re = df.loc[df["ChurnFlag"] == 0, "tenure"].mean()
chg_ch = df.loc[df["ChurnFlag"] == 1, "MonthlyCharges"].mean()
chg_re = df.loc[df["ChurnFlag"] == 0, "MonthlyCharges"].mean()
early = (df.loc[df["ChurnFlag"] == 1, "tenure"] <= 12).mean()

note(f"Customers: {len(df):,} | churned: {df['ChurnFlag'].sum():,} | churn rate: {overall:.1%}")
note(f"Monthly revenue: ${mrr:,.0f} | lost to churners: ${lost:,.0f} ({lost / mrr:.1%})")
note(f"Avg tenure  - churned: {ten_ch:.1f} mo vs retained: {ten_re:.1f} mo")
note(f"Avg monthly - churned: ${chg_ch:.2f} vs retained: ${chg_re:.2f}")
note(f"Share of churners who left within their first 12 months: {early:.1%}")

# %% 5. EDA: churn rate by every categorical feature --------------------------
CAT_FEATURES = [
    "Contract", "InternetService", "PaymentMethod", "TechSupport", "OnlineSecurity", "OnlineBackup",
    "DeviceProtection", "StreamingTV", "StreamingMovies", "PaperlessBilling", "SeniorCitizenLabel",
    "Partner", "Dependents", "MultipleLines", "PhoneService", "gender", "TenureGroup", "ChargeBand",
]
PRETTY = {
    "Contract": "Contract type", "InternetService": "Internet service", "PaymentMethod": "Payment method",
    "TechSupport": "Tech support", "OnlineSecurity": "Online security", "OnlineBackup": "Online backup",
    "DeviceProtection": "Device protection", "StreamingTV": "Streaming TV", "StreamingMovies": "Streaming movies",
    "PaperlessBilling": "Paperless billing", "SeniorCitizenLabel": "Senior citizen", "Partner": "Has partner",
    "Dependents": "Has dependents", "MultipleLines": "Multiple lines", "PhoneService": "Phone service",
    "gender": "Gender", "TenureGroup": "Tenure group", "ChargeBand": "Monthly charge band",
}

parts = []
for c in CAT_FEATURES:
    g = df.groupby(c)["ChurnFlag"].agg(customers="size", churn_rate="mean").reset_index()
    g = g.rename(columns={c: "value"})
    g.insert(0, "feature", c)
    parts.append(g)
seg = pd.concat(parts, ignore_index=True)
seg["churn_rate"] = seg["churn_rate"].round(4)
seg.to_csv(DATA / "churn_by_segment.csv", index=False)

# Rank features by the gap between their riskiest and safest level
# ("No internet/phone service" levels are structural, so they are left out of the ranking)
elig = seg[~seg["value"].isin(["No internet service", "No phone service"]) & (seg["customers"] >= 100)]
rows = []
for f, g in elig.groupby("feature"):
    hi, lo = g.loc[g["churn_rate"].idxmax()], g.loc[g["churn_rate"].idxmin()]
    rows.append({"feature": f, "gap": hi["churn_rate"] - lo["churn_rate"], "highest": hi["value"],
                 "lowest": lo["value"], "hi_rate": hi["churn_rate"], "lo_rate": lo["churn_rate"]})
drivers = pd.DataFrame(rows).sort_values("gap", ascending=False).reset_index(drop=True)

note("\n=== 4. TOP CHURN DRIVERS (gap between riskiest and safest level) ===")
for _, r in drivers.head(8).iterrows():
    note(f"{PRETTY[r['feature']]:<20} {r['gap'] * 100:4.0f} pts   "
         f"{r['highest']} {r['hi_rate']:.0%}  vs  {r['lowest']} {r['lo_rate']:.0%}")

# %% 6. EDA: numeric correlations + high-risk segment -------------------------
corr = df[["tenure", "MonthlyCharges", "TotalCharges", "AddOnServices"]].corrwith(df["ChurnFlag"]).round(3)
note("\n=== 5. CORRELATION WITH CHURN (numeric) ===")
for k, v in corr.items():
    note(f"{k:<16} {v:+.3f}")

hr = (df["Contract"] == "Month-to-month") & (df["InternetService"] == "Fiber optic") & (
    df["PaymentMethod"] == "Electronic check")
note("\n=== 6. HIGH-RISK SEGMENT: month-to-month + fiber optic + electronic check ===")
note(f"Customers: {hr.sum():,} ({hr.mean():.1%} of base) | churn rate: {df.loc[hr, 'ChurnFlag'].mean():.1%}")
note(f"Share of ALL churners in this segment: {df.loc[hr, 'ChurnFlag'].sum() / df['ChurnFlag'].sum():.1%}")
note(f"Churn rate everyone else: {df.loc[~hr, 'ChurnFlag'].mean():.1%}")

# %% 7. Charts -----------------------------------------------------------------
BLUE, ORANGE = "#2a78d6", "#eb6834"  # categorical slots 1 + 2: retained / churned
SURF, INK, INK2, MUTED, GRID, BASE = "#fcfcfb", "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7"
USD = r"\$"  # escaped so matplotlib doesn't read $...$ as math

plt.rcParams.update({
    "figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF,
    "text.color": INK, "axes.labelcolor": INK2, "axes.edgecolor": BASE,
    "xtick.color": MUTED, "ytick.color": MUTED, "xtick.labelcolor": INK2, "ytick.labelcolor": INK2,
    "axes.spines.top": False, "axes.spines.right": False, "axes.spines.left": False,
    "axes.grid": True, "axes.grid.axis": "y", "grid.color": GRID, "grid.linewidth": 0.8,
    "axes.axisbelow": True, "axes.titleweight": "bold", "axes.titlesize": 12,
    "axes.titlelocation": "left", "axes.titlecolor": INK, "axes.titlepad": 24,
})


def style_pct_axis(ax, top):
    ax.yaxis.set_major_formatter(PercentFormatter(1.0, decimals=0))
    ax.set_ylim(0, top)
    ax.tick_params(length=0, labelsize=9)


def subtitle(ax, text):
    ax.text(0, 1.03, text, transform=ax.transAxes, fontsize=9, color=INK2, va="bottom")


def bar_chart(ax, d, col, title, order=None):
    """Churn rate by category: one series, direct labels, dashed average line."""
    g = d.groupby(col)["ChurnFlag"].agg(rate="mean", n="size")
    g = g.loc[order] if order else g.sort_values("rate", ascending=False)
    ref = d["ChurnFlag"].mean()
    x = np.arange(len(g))
    ax.bar(x, g["rate"], width=0.56, color=ORANGE)
    ax.axhline(ref, color=MUTED, lw=1.2, ls=(0, (4, 3)))
    top = max(g["rate"].max(), ref) * 1.22
    for i, r in enumerate(g["rate"]):
        ax.text(i, r + top * 0.015, f"{r:.0%}", ha="center", va="bottom", fontsize=10, fontweight="bold",
                bbox=dict(fc=SURF, ec="none", pad=1.5), zorder=5)
    ax.set_xticks(x)
    ax.set_xticklabels([f"{textwrap.fill(str(k), 13)}\nn={n:,}" for k, n in zip(g.index, g["n"])], fontsize=9)
    style_pct_axis(ax, top)
    ax.set_title(title)
    worst = textwrap.shorten(str(g["rate"].idxmax()), 24, placeholder="...")
    subtitle(ax, f"Highest: {worst} {g['rate'].max():.0%}  |  dashed line = avg {ref:.0%}")
    return g


def tenure_curve(ax):
    bins = list(range(-1, 73, 6)) + ([72] if (72 + 1) % 6 else [])
    cut = pd.cut(df["tenure"], bins=[-1] + list(range(6, 73, 6)))
    g = df.groupby(cut, observed=True)["ChurnFlag"].mean()
    labels = [f"{max(int(i.left) + 1, 0)}-{int(i.right)}" for i in g.index]
    x = np.arange(len(g))
    ax.plot(x, g.values, color=ORANGE, lw=2, marker="o", ms=7, mfc=ORANGE, mec=SURF, mew=2)
    for i in (0, len(g) - 1):
        ax.text(i, g.values[i] + 0.025, f"{g.values[i]:.0%}", ha="center", fontsize=10, fontweight="bold")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=8.5)
    ax.set_xlabel("Tenure (months)", fontsize=9)
    style_pct_axis(ax, g.max() * 1.25)
    ax.set_title("Churn falls as tenure grows")
    subtitle(ax, "Churn rate by 6-month tenure bucket")


def driver_chart(ax, top_n=8):
    d = drivers.head(top_n).iloc[::-1]
    y = np.arange(len(d))
    ax.barh(y, d["gap"] * 100, height=0.55, color=ORANGE)
    ax.set_yticks(y)
    ax.set_yticklabels([PRETTY[f] for f in d["feature"]], fontsize=9.5)
    for i, (_, r) in enumerate(d.iterrows()):
        ax.text(r["gap"] * 100 + 1, i, f"{r['gap'] * 100:.0f} pts  ({r['highest']} vs {r['lowest']})",
                va="center", fontsize=8.5, color=INK2)
    ax.set_xlim(0, d["gap"].max() * 100 * 2.1)
    ax.grid(axis="y", visible=False)
    ax.grid(axis="x", visible=True)
    ax.tick_params(length=0, labelsize=9)
    ax.set_xlabel("Churn-rate gap, riskiest vs safest level (percentage points)", fontsize=9)
    ax.set_title("What separates churners from stayers")
    subtitle(ax, "Larger gap = stronger churn signal")


def charge_distribution(path):
    fig, axes = plt.subplots(1, 2, figsize=(9, 4.2), sharey=True)
    bins = np.arange(15, 125, 5)
    for ax, flag, color, name in [(axes[0], 0, BLUE, "Retained customers"), (axes[1], 1, ORANGE, "Churned customers")]:
        v = df.loc[df["ChurnFlag"] == flag, "MonthlyCharges"]
        ax.hist(v, bins=bins, weights=np.ones(len(v)) / len(v), color=color, rwidth=0.88)
        ax.axvline(v.mean(), color=INK2, lw=1.2, ls=(0, (4, 3)))
        ax.text(v.mean() + 1.5, ax.get_ylim()[1] * 0.97, f"mean {USD}{v.mean():.0f}", fontsize=9, color=INK2, va="top")
        ax.set_title(name, fontsize=11)
        ax.set_xlabel("Monthly charge", fontsize=9)
        ax.tick_params(length=0, labelsize=9)
    axes[0].yaxis.set_major_formatter(PercentFormatter(1.0, decimals=0))
    axes[0].set_ylabel("Share of customers", fontsize=9)
    fig.suptitle("Churners pay more per month", x=0.02, ha="left", fontsize=13, fontweight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    fig.savefig(path, dpi=150)
    plt.close(fig)


def kpi(ax, label, value, sub):
    ax.axis("off")
    ax.add_patch(FancyBboxPatch((0, 0), 1, 1, boxstyle="round,pad=0,rounding_size=0.08", transform=ax.transAxes,
                                fc="#f9f9f7", ec=GRID, lw=1))
    ax.text(0.06, 0.76, label, transform=ax.transAxes, fontsize=10, color=INK2, va="center")
    ax.text(0.06, 0.45, value, transform=ax.transAxes, fontsize=24, fontweight="bold", va="center")
    ax.text(0.06, 0.17, sub, transform=ax.transAxes, fontsize=9, color=INK2, va="center")


def save_single(draw, name, size=(7.5, 4.8)):
    fig, ax = plt.subplots(figsize=size)
    draw(ax)
    fig.tight_layout()
    fig.savefig(CHARTS / name, dpi=150)
    plt.close(fig)


TENURE_ORDER = ["0-12 months", "13-24 months", "25-48 months", "49-72 months"]
NET = df[df["InternetService"] != "No"]  # add-on comparisons only make sense for internet customers

save_single(lambda ax: bar_chart(ax, df, "Contract", "Churn rate by contract type",
                                 ["Month-to-month", "One year", "Two year"]), "01_churn_by_contract.png")
save_single(lambda ax: bar_chart(ax, df, "TenureGroup", "Churn rate by tenure group", TENURE_ORDER),
            "02_churn_by_tenure_group.png")
save_single(tenure_curve, "03_churn_by_tenure_curve.png")
save_single(lambda ax: bar_chart(ax, df, "InternetService", "Churn rate by internet service",
                                 ["DSL", "Fiber optic", "No"]), "04_churn_by_internet_service.png")
save_single(lambda ax: bar_chart(ax, df, "PaymentMethod", "Churn rate by payment method"),
            "05_churn_by_payment_method.png", size=(8.5, 4.8))
save_single(lambda ax: bar_chart(ax, NET, "TechSupport", "Tech support and churn (internet customers)",
                                 ["No", "Yes"]), "06_churn_by_tech_support.png")
save_single(lambda ax: bar_chart(ax, df, "ChargeBand", "Churn rate by monthly charge band",
                                 ["Low (<35)", "Medium (35-70)", "High (>70)"]), "07_churn_by_charge_band.png")
save_single(driver_chart, "08_churn_drivers.png", size=(9, 4.8))
charge_distribution(CHARTS / "09_monthly_charges_distribution.png")

# ---- one-page dashboard preview ----------------------------------------------
fig = plt.figure(figsize=(16, 10.5))
gs = fig.add_gridspec(3, 12, height_ratios=[0.5, 1, 1], hspace=0.85, wspace=1.4,
                      left=0.04, right=0.98, top=0.86, bottom=0.07)
kpi(fig.add_subplot(gs[0, 0:3]), "Customers", f"{len(df):,}", f"{df['ChurnFlag'].sum():,} churned")
kpi(fig.add_subplot(gs[0, 3:6]), "Churn rate", f"{overall:.1%}", "share of customers who left")
kpi(fig.add_subplot(gs[0, 6:9]), "Monthly revenue lost", f"{USD}{lost:,.0f}", f"{lost / mrr:.0%} of monthly revenue")
kpi(fig.add_subplot(gs[0, 9:12]), "Avg tenure of churners", f"{ten_ch:.0f} months", f"vs {ten_re:.0f} months for retained")

bar_chart(fig.add_subplot(gs[1, 0:4]), df, "Contract", "Churn by contract type", ["Month-to-month", "One year", "Two year"])
bar_chart(fig.add_subplot(gs[1, 4:8]), df, "TenureGroup", "Churn by tenure group", TENURE_ORDER)
bar_chart(fig.add_subplot(gs[1, 8:12]), df, "InternetService", "Churn by internet service", ["DSL", "Fiber optic", "No"])
bar_chart(fig.add_subplot(gs[2, 0:4]), df, "PaymentMethod", "Churn by payment method")
bar_chart(fig.add_subplot(gs[2, 4:8]), NET, "TechSupport", "Tech support (internet customers)", ["No", "Yes"])
bar_chart(fig.add_subplot(gs[2, 8:12]), df, "ChargeBand", "Churn by monthly charge", ["Low (<35)", "Medium (35-70)", "High (>70)"])

fig.text(0.04, 0.965, "Customer Churn Dashboard (preview)", fontsize=20, fontweight="bold", va="top")
fig.text(0.04, 0.925, "Static preview of the Power BI report layout. Synthetic Telco-style data for demonstration.",
         fontsize=11, color=INK2, va="top")
fig.savefig(CHARTS / "dashboard_preview.png", dpi=130)
plt.close(fig)
note("\nSaved 9 charts + dashboard_preview.png -> charts/")

(DATA / "analysis_log.txt").write_text("\n".join(log) + "\n", encoding="utf-8")
